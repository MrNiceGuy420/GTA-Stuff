/*
    Plugin-SDK (Grand Theft Auto 3) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CCutsceneObject.h"

// Converted from thiscall void CCutsceneObject::CCutsceneObject(void) 0x4BA910
CCutsceneObject::CCutsceneObject() {
    plugin::CallMethod<0x4BA910, CCutsceneObject *>(this);
}