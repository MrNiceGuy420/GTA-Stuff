/*
    Plugin-SDK (Grand Theft Auto 3) source file
    Authors: GTA Community. See more here
    https://github.com/DK22Pac/plugin-sdk
    Do not delete this comment block. Respect others' work!
*/
#include "CVector.h"

float CVector::Normalise() {
    return ((float(__thiscall *)(CVector *))0x4BA560)(this);
}
