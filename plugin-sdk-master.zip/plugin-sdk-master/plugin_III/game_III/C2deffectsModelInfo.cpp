/*
Plugin-SDK (Grand Theft Auto 3) source file
Authors: GTA Community. See more here
https://github.com/DK22Pac/plugin-sdk
Do not delete this comment block. Respect others' work!
*/
#include "C2deffectsModelInfo.h"

// Converted from thiscall void C2deffectsModelInfo::C2deffectsModelInfo(void) 0x50BE60 
C2deffectsModelInfo::C2deffectsModelInfo() {
    plugin::CallMethod<0x50BE60, C2deffectsModelInfo *>(this);
}

// Converted from thiscall void C2deffectsModelInfo::~C2deffectsModelInfo() 0x50BE50 
C2deffectsModelInfo::~C2deffectsModelInfo() {
    plugin::CallMethod<0x50BE50, C2deffectsModelInfo *>(this);
}

// Converted from thiscall void CStore<C2dEffect,2000>::~CStore() 0x50BE30 
EffectStore::~EffectStore() {
    plugin::CallMethod<0x50BE30, EffectStore *>(this);
}
