## Universal Turnlights
Player and NPCs can use vehicle turnlights.

![Img1](http://i.imgur.com/3HNQYfo.png) ![Img2](http://i.imgur.com/9exDxHT.png)