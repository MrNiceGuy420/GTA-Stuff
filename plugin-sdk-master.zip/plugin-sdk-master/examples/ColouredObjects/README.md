## Coloured Objects
Each object has its own color.

![Img1](http://i.imgur.com/2PB6OGm.png) ![Img2](http://i.imgur.com/4BzZWG8.png)