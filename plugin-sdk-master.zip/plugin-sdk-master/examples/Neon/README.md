## Neon
Player and NPCs can use vehicle neon illumination working from 21 o'clock till 6 o'clock.

![Img1](http://i.imgur.com/oGL1qvv.png) ![Img2](http://i.imgur.com/Suys7u8.png)