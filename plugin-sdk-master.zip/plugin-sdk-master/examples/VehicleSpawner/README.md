## Vehicle Spawner
A vehicle is spawned when its name is entered as a cheatcode.

![Img1](http://i.imgur.com/BJDAcrq.png) ![Img2](http://i.imgur.com/ULBlbqB.png)