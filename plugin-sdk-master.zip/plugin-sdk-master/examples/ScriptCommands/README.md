## Script commands
Script commands example for GTA SA, GTA VC and GTA 3.