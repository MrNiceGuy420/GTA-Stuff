## DX Font
Drawing text with ID3DXFont.

![Img1](http://i.imgur.com/QSoLT3A.png) ![Img2](http://i.imgur.com/hNOk66p.png)