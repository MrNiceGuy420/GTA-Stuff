## Speedometer

![Img1](http://i.imgur.com/9zecxix.png) ![Img2](http://i.imgur.com/3Z6HuWs.png)