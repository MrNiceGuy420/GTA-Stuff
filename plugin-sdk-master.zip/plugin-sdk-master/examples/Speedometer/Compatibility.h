#pragma once

class Compatibility {
public:
    static void PrintAreaName(float x, float y, char *text);
    static void PrintVehicleName(float x, float y, char *text);
    static void InstallCompatibilityPatches();
};