## Create Car
Creates a car when TAB is pressed.