## Random Ped Spawner
Spawns random male and female pedestrians in front of the player when F9 is pressed.

![Img1](http://i.imgur.com/J1m0lHH.png) ![Img2](http://i.imgur.com/BrkDKbn.png)

#### Controls (keyboard)
* F9 - Spawn Ped
