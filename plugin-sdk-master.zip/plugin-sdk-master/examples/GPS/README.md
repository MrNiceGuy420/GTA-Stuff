## GPS
GPS will show you a path to destination marker on the radar and in the menu map.

![Img1](http://i.imgur.com/ngpI4l9.png) ![Img2](http://i.imgur.com/HEdioc6.png)