## Full Nitrous Control
Based on [Wesser](http://gtaforums.com/user/172776-wesser/)'s code.

http://www.gtagarage.com/mods/show.php?id=19010

#### Additional Controls (keyboard)
* `N` + `1` - Install 1X nitro
* `N` + `2` - Install 2X nitro
* `N` + `3` - Install 3X nitro
* `N` + `4` - Install 4X nitro
* `N` + `5` - Install 5X nitro
* `N` + `6` - Install 6X nitro
* `N` + `7` - Install 7X nitro
* `N` + `8` - Install 8X nitro
* `N` + `9` - Install 9X nitro
* `N` + `0` - Install 10X nitro
* `N` + `-` - Remove nitro
* `N` + `=` - Install infinite nitro