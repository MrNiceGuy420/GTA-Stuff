## Hand Signals
Play ped hand signals animations.

![Img1](http://i.imgur.com/z3uK6QY.png) ![Img2](http://i.imgur.com/ZKbv04y.png)

#### Controls (keyboard)
* 1 - Animation #1
* 2 - Animation #2
* 3 - Animation #3
* 4 - Animation #4
* 5 - Animation #5
