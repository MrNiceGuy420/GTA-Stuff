
	> Upgraded Wheels SA Reflections <

	Improved custom wheels used in Transfender & Wheel Arch Angels. The tyres and brake calipers will not reflect, while the main rim area always will.


	> Version 1
	� Light SA reflection "vehicleenvmap128" added to metallic parts.
	� Brakes and rubber will not reflect even with graphics mods.
	� Added brake caliper to some wheels that did not have it.


	> Installation:
	Drag the "UV SA Chrome Wheels" into your "modloader folder".


	> Notes & tips:
	Recommended to use with:
	
	GFX Hack:
	https://www.mixmods.com.br/2015/06/gfx-hack-correcao-de-cromos-e-reflexos.html
	or
	SkyGfx (Xbox reflections):
	https://www.mixmods.com.br/2016/09/SkyGfx.html
	

	> Permissions:
	Upgraded Wheels SA Reflections by Scooper, this mod is open source.