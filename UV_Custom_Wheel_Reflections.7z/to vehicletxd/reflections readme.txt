- The custom wheels reflect & respond to "wheelenvmap128"

#Open your "vehicle.txd" and ADD this texture to it for SA reflections. Or you can put a black texture to disable the effect.
[GTA SA Directory > models > generic > vehicle.txd]

#Regardless, make sure the texture is in "vehicle.txd" otherwise it can look buggy, especially when using graphics mods such as SkyGfx, ENB Series and RenderHook.