
	> Upgraded Wheels SA Version <

	Improved custom wheels used in Transfender & Wheel Arch Angels. The tyres and brake calipers will not reflect, while the main rim area has the possibility to do so.


	> Version 1
	� Metallic parts have specular lighting and will reflect under very specific circumstances (e.g. Renderhook).
	� Brakes and rubber will not reflect even with graphics mods.
	� Added brake caliper to some wheels that did not have it.


	> Installation:
	Drag the "UV SA Wheels" into your "modloader" folder.


	> Permissions:
	Upgraded SA Wheels by Scooper, this mod is open source.